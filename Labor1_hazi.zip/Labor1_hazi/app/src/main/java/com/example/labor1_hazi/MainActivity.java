package com.example.labor1_hazi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText number1=findViewById(R.id.editTextNumber);
        final EditText number2=findViewById(R.id.editTextNumber2);
        final TextView eredmeny = findViewById(R.id.textView);
        Button plus = findViewById(R.id.button);
        Button multi = findViewById(R.id.button2);
        Button minus = findViewById(R.id.button3);
        Button divid = findViewById(R.id.button4);

        plus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                double a = Double.parseDouble(number1.getText().toString())+ Double.parseDouble(number2.getText().toString());
                eredmeny.setText(Double.toString(a));
            }
        });
        multi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                double a = Double.parseDouble(number1.getText().toString())* Double.parseDouble(number2.getText().toString());
                eredmeny.setText(Double.toString(a));
            }
        });
        minus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                double a = Double.parseDouble(number1.getText().toString())- Double.parseDouble(number2.getText().toString());
                eredmeny.setText(Double.toString(a));
            }
        });
        divid.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                double a = Double.parseDouble(number1.getText().toString())/ Double.parseDouble(number2.getText().toString());
                eredmeny.setText(Double.toString(a));
            }
        });
    }
}