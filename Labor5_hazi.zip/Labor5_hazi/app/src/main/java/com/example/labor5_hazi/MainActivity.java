package com.example.labor5_hazi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    ListView lista;
    ArrayAdapter<String> adapter;
    ArrayList<String> array_lista = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        array_lista.add("Kalapács");
        array_lista.add("Szög");
        array_lista.add("Csavarhúzó");
        array_lista.add("Szike");
        array_lista.add("Csavar");
        array_lista.add("Smirgli");


        lista = findViewById(R.id.lista);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, array_lista);
        registerForContextMenu(lista);
        lista.setAdapter(adapter);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.Sort:
                Collections.sort(array_lista, new Comparator<CharSequence>() {
                    @Override
                    public int compare(CharSequence a1, CharSequence a2) {
                        return a1.toString().compareTo(a2.toString());
                    }
                });
                adapter.notifyDataSetChanged();
                break;

            case R.id.Delete:
                array_lista.clear();
                adapter.notifyDataSetChanged();
                break;
            default:
                return false;
        }
        return true;
    }


}